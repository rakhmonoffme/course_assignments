import streamlit 
streamlit.title("Streamlit App for the Class")
streamlit.write("This is a simple Streamlit app for the 3rd class.")
streamlit.write("You can use this app to demonstrate the functionality of your 3rd class project.")
name = streamlit.text_input("Enter your name:")
if name:
    streamlit.write(f"Hello, {name}! Welcome to the Streamlit app for our class.")
streamlit.write("This app is designed to help you learn and practice your skills.")
streamlit.button("Click here to get the results!")